#-*- coding:utf-8 -*-

# 네이버 검색 Open API 예제
import json
import random
import urllib.request
import webbrowser
from collections import Counter

import pytagcloud
from bs4 import BeautifulSoup, NavigableString, Comment
from konlpy.tag import Kkma
from konlpy.utils import pprint

client_id = "RdEemi6FBrMzlIrFvrj3"
client_secret = "uCj3JBXkUV"
encText = urllib.parse.quote("SK")
url = "https://openapi.naver.com/v1/search/news?query=" + encText + "&display=10&sort=sim" # json 결과
# url = "https://openapi.naver.com/v1/search/news.xml?query=" + encText + "&display=10&sort=sim" # xml 결과
request = urllib.request.Request(url)
request.add_header("X-Naver-Client-Id",client_id)
request.add_header("X-Naver-Client-Secret",client_secret)
response = urllib.request.urlopen(request)
rescode = response.getcode()


if(rescode==200):
    response_body = response.read()
    j = json.loads(response_body.decode('utf-8'))
    # print(response_body.decode('utf-8'))
    # print(j)
    for i in range(0, len(j)):
        print(j["items"][i]['title'])
        print(j["items"][i]['originallink'])
        print(j["items"][i]['link'])
        print(j["items"][i]['description'])
        print(j["items"][i]['pubDate'])

else:
    print("Error Code:" + rescode)

# Beautiful Soup을 이용한 페이지                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   Crawling & Parsing
targetUrl = "http://news.naver.com/main/read.nhn?mode=LSD&mid=sec&sid1=105&oid=092&aid=0002113500"
soup = BeautifulSoup(urllib.request.urlopen(targetUrl).read(), "lxml")
#print(soup.prettify())

newsbody = soup.find(id="articleBodyContents")
#print(newsbody.contents)
bodystr = ""
for child in newsbody.children:
    if (isinstance(child, NavigableString) and not isinstance(child, Comment)):
        print(child.string.strip())
        bodystr += child.string.strip()

# 형태소 분석
kkma = Kkma()
pprint(kkma.nouns(bodystr))
pprint(kkma.pos(bodystr))

# Word Cloud
def get_tags(text, ntags=50, multiplier=10):
#    h = Hannanum()
    nouns = text
    count = Counter(nouns)
    return [{'color': color(), 'tag': n, 'size': c*multiplier} for n, c in count.most_common(ntags)]

def draw_cloud(tags, filename, fontname='Ngulim', size=(800, 600)):
    pytagcloud.create_tag_image(tags, filename, fontname=fontname, size=size)
    webbrowser.open(filename)

r = lambda: random.randint(0,255)
color = lambda: (r(), r(), r())

tags = get_tags(kkma.nouns(bodystr))
draw_cloud(tags, "wordcloud.jpg")

